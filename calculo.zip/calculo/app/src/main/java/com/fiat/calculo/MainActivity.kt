package com.fiat.calculo

// Importações necessárias
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val number1EditText = findViewById<EditText>(R.id.number1EditText)
        val number2EditText = findViewById<EditText>(R.id.number2EditText)
        val calculateButton = findViewById<Button>(R.id.calculateButton)

        calculateButton.setOnClickListener {
            val number1 = number1EditText.text.toString().toFloatOrNull()
            val number2 = number2EditText.text.toString().toFloatOrNull()

            if (number1 != null && number2 != null) {
                val sum = number1 + number2

                Toast.makeText(this, "A soma é: $sum", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Por favor, insira números válidos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
